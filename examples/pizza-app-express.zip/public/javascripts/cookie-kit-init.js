XcooBee.kit.initialize({
    checkByDefaultTypes: "application",
    targetUrl: "/cookiesetter",    
    position: "right_bottom",
    privacyUrl: "/privacy",
    requestDataTypes: ["application","usage","statistics"],      
    termsUrl: "/terms",
    textMessage: "Welcome to our pizza site. We use these types of cookies. Please let us know if this is OK.",
    testMode: true
  });